import { useState } from 'react';
import EmbedPlayer from './EmbedPlayer';

export default function Search() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);

  const doSearch = async (e) => {
    e.preventDefault();
    if (!q) return;
    const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
    const data = await res.json();
    setResults(data.tracks.items || []);
  };

  return (
    <div>
      <form onSubmit={doSearch}>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search Spotify tracks..." />
        <button type="submit">Search</button>
      </form>
      <div>
        {results.map(track => (
          <div key={track.id}>
            <strong>{track.name}</strong> - {track.artists[0].name}
            <EmbedPlayer uri={track.id} type="track" />
          </div>
        ))}
      </div>
    </div>
  );
}