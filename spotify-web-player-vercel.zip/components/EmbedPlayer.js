export default function EmbedPlayer({ uri, type='track' }) {
  return <iframe src={`https://open.spotify.com/embed/${type}/${uri}`} width="300" height="80" frameBorder="0" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>;
}