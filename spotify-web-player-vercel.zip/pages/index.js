import Search from '../components/Search';

export default function Home() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Spotify Web Player</h1>
      <a href="/api/login">Log in with Spotify</a>
      <Search />
    </div>
  );
}