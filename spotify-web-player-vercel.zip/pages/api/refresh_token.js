import { refreshAccessToken } from '../../lib/spotify';
import cookie from 'cookie';

export default async function handler(req, res) {
  const cookies = cookie.parse(req.headers.cookie || '');
  const refresh_token = cookies.spotify_refresh_token;
  if (!refresh_token) return res.status(401).json({ error: 'No refresh token' });
  const tokenResponse = await refreshAccessToken(refresh_token);
  if (tokenResponse.error) return res.status(400).json(tokenResponse);
  res.setHeader('Set-Cookie', cookie.serialize('spotify_access_token', tokenResponse.access_token, { path: '/', maxAge: tokenResponse.expires_in }));
  res.json({ access_token: tokenResponse.access_token });
}