import { spotifyApi } from '../../lib/spotify';

export default async function handler(req, res) {
  const { q, type='track' } = req.query;
  const access_token = req.cookies?.spotify_access_token;
  if (!access_token) return res.status(401).json({ error: 'Not authenticated' });
  const url = `/search?q=${encodeURIComponent(q)}&type=${type}&limit=10`;
  const data = await spotifyApi(url, access_token);
  res.json(data);
}