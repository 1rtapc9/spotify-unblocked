export default function handler(req, res) {
  const base = 'https://accounts.spotify.com/authorize';
  const redirect_uri = `${process.env.NEXT_PUBLIC_BASE_URL}/api/callback`;
  const scopes = ['user-read-private','user-read-email','playlist-read-private','user-top-read'].join(' ');
  const params = new URLSearchParams({ response_type: 'code', client_id: process.env.SPOTIFY_CLIENT_ID, scope: scopes, redirect_uri }).toString();
  res.redirect(`${base}?${params}`);
}