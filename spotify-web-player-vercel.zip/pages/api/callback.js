import { exchangeCodeForToken } from '../../lib/spotify';
import cookie from 'cookie';

export default async function handler(req, res) {
  const code = req.query.code;
  if (!code) return res.status(400).send('No code provided');
  const tokenResponse = await exchangeCodeForToken(code);
  if (tokenResponse.error) return res.status(400).json(tokenResponse);
  const cookies = [
    cookie.serialize('spotify_access_token', tokenResponse.access_token, { path: '/', maxAge: tokenResponse.expires_in }),
    cookie.serialize('spotify_refresh_token', tokenResponse.refresh_token, { httpOnly: true, path: '/' })
  ];
  res.setHeader('Set-Cookie', cookies);
  res.redirect('/');
}